cd sql
db2 -f createDB.sql
cd ../java
. installJava.sh
cd ../sql
. createfunctions.sh
cd ..