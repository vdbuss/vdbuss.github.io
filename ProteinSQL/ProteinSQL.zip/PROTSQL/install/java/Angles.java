
public class Angles {

	public static double computeTorsionAngle(double ax,double ay,double az,double bx,double by,double bz,double cx,double cy,double cz,double dx,double dy,double dz) {
		double abx,aby,abz,cbx,cby,cbz,cdx,cdy,cdz;
		double ndax,nday,ndaz,neax,neay,neaz;//normalen van het vlak
		double bl,el,bel;
		 abx = ax - bx;
		 aby = ay - by;
		 abz = az - bz;
		 cbx = cx - bx;
		 cby = cy - by;
		 cbz = cz - bz;
		 cdx = cx - dx;
		 cdy = cy - dy;
		 cdz = cz - dz;
		//normalen op de 2 vlakken berekenen obv cross product
		//N1 
		  ndax = aby * cbz - abz * cby;
		  nday = abz * cbx - abx * cbz;
		  ndaz = abx * cby - aby * cbx;
		//N2
		  neax = cbz * cdy - cby * cdz;
		  neay = cbx * cdz - cbz * cdx;
		  neaz = cby * cdx - cbx * cdy;
		  bl=(double)(Math.sqrt((double)( ndax*ndax + nday*nday + ndaz*ndaz) )); 
		  el=(double)(Math.sqrt((double)( neax*neax + neay*neay + neaz*neaz) ));
		  bel=(double)(ndax*neax+nday*neay+ndaz*neaz);
			if(bl*el==0)
				return 720;//tempRes;
			bel /= (bl * el);
			if (bel > 1.0)
			{
			bel = 1;
			}
			else if (bel < -1.0)
			{
			bel = -1;
			}
			
			double acosbel = (double) Math.acos(bel);
			if ((cbx * (ndaz * neay - nday * neaz)
			+ cby * (ndax * neaz - ndaz * neax)
			+ cbz * (nday * neax - ndax * neay))
			< 0)
			{
			acosbel = -acosbel;
			}
			
			acosbel = (acosbel > 0.0)? Math.PI - acosbel : -(Math.PI + acosbel);
			//return tempRes;
			return Math.rint(Math.toDegrees(acosbel));
	}
	
	//eerste 6 params zijn de coordinaten van de axis, 7de angel
	public static double[] rotateAtom(double rAx,double rAy,double rAz,double rBx,double rBy,double rBz,double angel,double rPx,double rPy,double rPz)
	{ 
		 double cosAngel,sinAngel,norm;
		 double [] V= new double[3];
		 double [] P = new double[3];// original point
		 double [] Res=new double[3];//result point
		 Res[0]=0;
		 Res[1]=0;
		 Res[2]=0; 
		 V[0]=rBx-rAx;
		 V[1]=rBy-rAy;
		 V[2]=rBz-rAz;
		 P[0]=rPx;
		 P[1]=rPy; 
		 P[2]=rPz;
		 P[0]-=rAx;
		 P[1]-=rAy; 
		 P[2]-=rAz;
		 norm=Math.sqrt((V[0]*V[0]+V[1]*V[1]+V[2]*V[2]));
		 V[0]=(V[0]/norm);
		 V[1]=(V[1]/norm);
		 V[2]=(V[2]/norm);
		cosAngel = Math.cos(angel);
		 sinAngel = Math.sin(angel);
		 Res[0] += (cosAngel + (1 - cosAngel) * V[0] * V[0]) * P[0];
		 Res[0]+= ((1 - cosAngel) * V[0] * V[1] - V[2] * sinAngel) * P[1];
		 Res[0]+= ((1 - cosAngel) * V[0] * V[2]+ V[1] * sinAngel) * P[2];

		 Res[1]+= ((1 - cosAngel) * V[0] *V[1] + V[2] * sinAngel) * P[0];
		 Res[1]+= (cosAngel + (1 - cosAngel) * V[1] * V[1]) * P[1];
		 Res[1] += ((1 - cosAngel) * V[1]* V[2]- V[0] * sinAngel) * P[2];

		 Res[2] += ((1 - cosAngel) * V[0] * V[2] - V[1] * sinAngel) * P[0];
		 Res[2] += ((1 - cosAngel) * V[1] * V[2] + V[0] * sinAngel) *P[1];
		 Res[2] += (cosAngel + (1 - cosAngel) * V[2] * V[2]) * P[2];

		 Res[0] += rAx;
		 Res[1] += rAy;
		 Res[2] += rAz;
		 //System.out.println( " X,Y,Z result -- : " +( Res[0])+" "+ Res[1]+" "+ Res[2]+" " );
		 
		 
		 return Res;
	

	}		
	public static double rotateAtomX(double rAx,double rAy,double rAz,double rBx,double rBy,double rBz,double angel,double rPx,double rPy,double rPz)
	{ 
		 double cosAngel,sinAngel,norm;
		 double [] V= new double[3];
		 double [] P = new double[3];// original point
		 double [] Res=new double[3];//result point
		 Res[0]=0;
		 Res[1]=0;
		 Res[2]=0;
		 V[0]=rBx-rAx;
		 V[1]=rBy-rAy;
		 V[2]=rBz-rAz;
		 P[0]=rPx;
		 P[1]=rPy; 
		 P[2]=rPz;
		 P[0]-=rAx;
		 P[1]-=rAy; 
		 P[2]-=rAz;
		 norm=Math.sqrt((V[0]*V[0]+V[1]*V[1]+V[2]*V[2]));
		 V[0]=(V[0]/norm);
		 V[1]=(V[1]/norm);
		 V[2]=(V[2]/norm);
		 cosAngel = Math.cos(angel);
		 sinAngel = Math.sin(angel);
		 Res[0] += (cosAngel + (1 - cosAngel) * V[0] * V[0]) * P[0];
		 Res[0]+= ((1 - cosAngel) * V[0] * V[1] - V[2] * sinAngel) * P[1];
		 Res[0]+= ((1 - cosAngel) * V[0] * V[2]+ V[1] * sinAngel) * P[2];
		 Res[0] += rAx;
		 return Res[0];
	}		
		
		
	public static double rotateAtomY(double rAx,double rAy,double rAz,double rBx,double rBy,double rBz,double angel,double rPx,double rPy,double rPz)
	{ 
		 double cosAngel,sinAngel,norm;
		 double [] V= new double[3];
		 double [] P = new double[3];// original point
		 double [] Res=new double[3];//result point
		 Res[0]=0;
		 Res[1]=0;
		 Res[2]=0;
		 V[0]=rBx-rAx;
		 V[1]=rBy-rAy;
		 V[2]=rBz-rAz;
		 P[0]=rPx;
		 P[1]=rPy; 
		 P[2]=rPz;
		 P[0]-=rAx;
		 P[1]-=rAy; 
		 P[2]-=rAz;
		 norm=Math.sqrt((V[0]*V[0]+V[1]*V[1]+V[2]*V[2]));
		 V[0]=(V[0]/norm);
		 V[1]=(V[1]/norm);
		 V[2]=(V[2]/norm);
		 cosAngel = Math.cos(angel);
		 sinAngel = Math.sin(angel);
		 Res[1]+= ((1 - cosAngel) * V[0] *V[1] + V[2] * sinAngel) * P[0];
		 Res[1]+= (cosAngel + (1 - cosAngel) * V[1] * V[1]) * P[1];
		 Res[1] += ((1 - cosAngel) * V[1]* V[2]- V[0] * sinAngel) * P[2];
		 Res[1] += rAy;
		 return(Res[1]);
	}	
	public static double rotateAtomZ(double rAx,double rAy,double rAz,double rBx,double rBy,double rBz,double angel,double rPx,double rPy,double rPz)
	{ 
		 double cosAngel,sinAngel,norm;
		 double [] V= new double[3];
		 double [] P = new double[3];// original point
		 double [] Res=new double[3];//result point
		 Res[0]=0;
		 Res[1]=0;
		 Res[2]=0; V[0]=rBx-rAx;
		 V[1]=rBy-rAy;
		 V[2]=rBz-rAz;
		 P[0]=rPx;
		 P[1]=rPy; 
		 P[2]=rPz;
		 P[0]-=rAx;
		 P[1]-=rAy; 
		 P[2]-=rAz;
		 norm=Math.sqrt((V[0]*V[0]+V[1]*V[1]+V[2]*V[2]));
		 V[0]=(V[0]/norm);
		 V[1]=(V[1]/norm);
		 V[2]=(V[2]/norm);
		 cosAngel = Math.cos(angel);
		 sinAngel = Math.sin(angel);
		 Res[2] += ((1 - cosAngel) * V[0] * V[2] - V[1] * sinAngel) * P[0];
		 Res[2] += ((1 - cosAngel) * V[1] * V[2] + V[0] * sinAngel) *P[1];
		 Res[2] += (cosAngel + (1 - cosAngel) * V[2] * V[2]) * P[2];
		 Res[2] += rAz;
		 return(Res[2]);
	}	
	
	
}



