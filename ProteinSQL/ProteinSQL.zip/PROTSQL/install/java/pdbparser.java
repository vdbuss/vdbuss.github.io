import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.sql.*;
import java.util.Vector;

public class pdbparser{
  /* members */
  static private FileInputStream m_fileInput;
  static private BufferedReader m_bufInput;
  static private String m_line;
  static private dbconnection2 m_db;

  /* buffermembers */
  static private Vector m_atoms;
  static private boolean m_bad;
  static private boolean m_pdb_exists;
  static private boolean m_complex;
  static private String m_cause_of_badness;
  static private String m_pdbid;
  static private String m_cause;
  static private String m_current_chain;
  static private Vector m_atom_lines;
  static private Vector m_seqres;
  static private Vector m_seqres_chainid;
  static private int m_current_aaid;
  private static String m_status;
  private static String m_cause_status;

  /* constructor */
  protected pdbparser() {
      initialize();
  }

  private static void initialize(){
      pdbparser.m_line = "";
      pdbparser.m_db = new dbconnection2();
      pdbparser.m_atoms = new Vector();
      pdbparser.m_bad = false;
      pdbparser.m_pdb_exists = false;
      pdbparser.m_cause_of_badness = "";
      pdbparser.m_atom_lines = new Vector();
      pdbparser.m_seqres = new Vector();
      pdbparser.m_seqres_chainid = new Vector(); 
      pdbparser.m_pdbid = "";
      pdbparser.m_complex = false;
      pdbparser.m_cause = "";
      pdbparser.m_current_aaid = 0;
      pdbparser.m_current_chain = "";
      pdbparser.m_status = "perfect";
      pdbparser.m_cause_status = "";
  }

  public static void readFile(String filename, String output[]) {
    initialize();

    try
    {
        char unbound;
        File f = new File(filename.trim());

        pdbparser.m_fileInput = new FileInputStream(f);
        pdbparser.m_bufInput = new BufferedReader(new InputStreamReader(pdbparser.m_fileInput));
        pdbparser.m_pdb_exists = false;
        pdbparser.m_bad = false;
        pdbparser.m_atoms = new Vector();

        getAtoms();

        while (((pdbparser.m_line = pdbparser.m_bufInput.readLine()) != null) &&
                          !pdbparser.m_bad) {
            parseLine();
        }

        if (!pdbparser.m_bad)
            clearRemainingBuffers();

        if (pdbparser.m_complex)
            unbound = '0';
        else
            unbound = '1';

        if (!pdbparser.m_bad && !pdbparser.m_pdb_exists) { // pdb-file not valid
            String insertPDB = "update PDB set unbound = '" + unbound +
                               "', cause = '" + pdbparser.m_cause +
                               "' where pdbid = '" + pdbparser.m_pdbid + "'";
            pdbparser.m_db.execUpdate(insertPDB);
        }
        pdbparser.m_bufInput.close();
        pdbparser.m_fileInput.close();
    } catch (Exception e) {
        pdbparser.m_bad = true;
        pdbparser.m_cause_of_badness = "File error: " + e.toString();
        if (!pdbparser.m_pdb_exists)
            undoInsert();
        pdbparser.m_db.close();
        e.printStackTrace();
        output[0] = "ERROR: " + pdbparser.m_cause_of_badness;
    }

    output[0] = checkValidity();
  }

  /* checks if pdb-file has been processed valid */
  private static String checkValidity() {
      if (pdbparser.m_bad) { // pdb-file not valid
          if (!pdbparser.m_pdb_exists)
              undoInsert();

          pdbparser.m_db.close();
          return "ERROR: " + pdbparser.m_cause_of_badness;
      } else { // pdb-file valid
          pdbparser.m_db.close();
          return "The file is inserted into the database!";
      }
  }

  /* checks if pdb-file has been processed valid */
  private static void getAtoms() throws InstantiationException,SQLException,IllegalAccessException,ClassNotFoundException{
          ResultSet resset = pdbparser.m_db.execQuery("select aa, atomname from atomname");

          while(resset.next())
                  pdbparser.m_atoms.addElement(resset.getString(1).trim()+resset.getString(2).trim());
          resset.close();
  }

  /* this functions undos the changes to the database in case a invalid
   * file has been written the database*/
  private static void undoInsert(){
          String delete;

          try{
        	  delete = "delete from HELIX where PDBid ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from STRAND where PDBid ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from TURN where PDBid ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from ATOMPOS where PDBID ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from ALT where PDBID ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from AA where PDBID ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);

        	  delete = "delete from PDB where PDBid ='"+ pdbparser.m_pdbid+"'";
        	  pdbparser.m_db.execUpdate(delete);
                  
 
                  
          } catch (SQLException ex) {
                  ex.printStackTrace();
                  pdbparser.m_db.close();
          } catch (InstantiationException ex) {
                  ex.printStackTrace();
                  pdbparser.m_db.close();
          } catch (IllegalAccessException ex) {
                  ex.printStackTrace();
                  pdbparser.m_db.close();
          } catch (ClassNotFoundException ex) {
                  ex.printStackTrace();
                  pdbparser.m_db.close();
          }
  }


  /* this function takes care of the parsing of one line */
  private static void parseLine() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
	  	  if(pdbparser.m_line.toLowerCase().startsWith("header "))
                  parseHeader();
          else if(pdbparser.m_line.toLowerCase().startsWith("title "))
                  parseTitle();
          else if(pdbparser.m_line.toLowerCase().startsWith("seqres "))
                  parseSeqres();
          else if(pdbparser.m_line.toLowerCase().startsWith("atom "))
                  parseAtom();
          else if(pdbparser.m_line.toLowerCase().startsWith("remark   2")) // 3 spaces between remark and 2
                  parseRemark();
          else if(pdbparser.m_line.toLowerCase().startsWith("helix "))
        	  	  parseHelices();
          else if(pdbparser.m_line.toLowerCase().startsWith("turn "))
        	  	  parseTurns();
          else if(pdbparser.m_line.toLowerCase().startsWith("sheet "))
        	  	  parseSheets();
  }

  private static void parseSheets() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
      String sheetid = pdbparser.m_line.substring(11,14).trim();
	  int strandid = convertToInt(pdbparser.m_line.substring(7,10));
	  String initchainid = pdbparser.m_line.substring(21,22);
	  int initaaid = convertToInt(pdbparser.m_line.substring(22,26));
	  String endchainid = pdbparser.m_line.substring(32,33);
	  int endaaid = convertToInt(pdbparser.m_line.substring(33,37));
	  int curaaid = convertToInt(pdbparser.m_line.substring(50,54));
	  String curchainid = pdbparser.m_line.substring(49,50);
	  
	  String curaaname = pdbparser.m_line.substring(45,48);
	  String curatomname = pdbparser.m_line.substring(41,45).trim();
	  int curatomid = findAtomId( curaaname , curatomname );

	  int prevaaid = convertToInt(pdbparser.m_line.substring(65,69));
	  String prevchainid = pdbparser.m_line.substring(64,65);

	  String prevaaname = pdbparser.m_line.substring(60,63);
	  String prevatomname = pdbparser.m_line.substring(56,60).trim();
	  int prevatomid = findAtomId( prevaaname, prevatomname );
	  
	  int sense;
	  if (pdbparser.m_line.substring(38, 40).equals("-1"))
		  sense = -1;
	  else if (pdbparser.m_line.substring(38, 40).equals(" 0"))
		  sense = 0;
	  else
		  sense = 1;
	  String update = "INSERT INTO STRAND(pdbid, sheetid, strandid, initchainid, initaaid, endchainid, endaaid, "
		  			  + "curaaid, curchainid, curatomid, prevaaid, prevchainid, prevatomid, sense) values ("
					  + "'" + pdbparser.m_pdbid + "'" + ", " + "'" + sheetid + "'" + ", " +  strandid + ", "
					  + "'" + initchainid + "'" + ", "  + initaaid + ", " + "'" + endchainid + "'" + ", " + endaaid + ", " 
					  + curaaid + "," + "'" + curchainid + "'" + ", " + curatomid + ", "
					  + prevaaid + "," + "'" + prevchainid + "'" + ", " + prevatomid + ", " + sense + ")";
	  pdbparser.m_db.execUpdate(update);
}

private static int findAtomId(String aaname, String atomname) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
	String q = "SELECT atomid FROM atomname WHERE atomname = '" + atomname.trim() + "'"
	+ " AND aa = '" + aaname.trim() + "'";
	ResultSet rs = pdbparser.m_db.execQuery(q);
	if (rs.next())
		return rs.getInt(1);
	return 0;
}

private static void parseTurns() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    String turnid = pdbparser.m_line.substring(7,10);
	String initchainid = pdbparser.m_line.substring(19,20);
	int initaaid = convertToInt(pdbparser.m_line.substring(20,24));
	String endchainid = pdbparser.m_line.substring(30,31);
	int endaaid = convertToInt(pdbparser.m_line.substring(31,35));
	String update = "INSERT INTO TURN(pdbid, turnid, initchainid, initaaid, endchainid, endaaid) values ("
				  + "'" + pdbparser.m_pdbid + "'" + ", " + turnid + ", " + "'" + initchainid + "'" + ", "
				  + initaaid + ", " + "'" + endchainid + "'" + ", " + endaaid + ")";
	pdbparser.m_db.execUpdate(update);
}

private static void parseHelices() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    int helixid = convertToInt(pdbparser.m_line.substring(7,10));
	int helixclassid = convertToInt(pdbparser.m_line.substring(38,40));
	String initchainid = pdbparser.m_line.substring(19,20);
	int initaaid = convertToInt(pdbparser.m_line.substring(21,25));
	String endchainid = pdbparser.m_line.substring(31,32);
	int endaaid = convertToInt(pdbparser.m_line.substring(33,37));
	String comment = pdbparser.m_line.substring(40,70);
	String update = "INSERT INTO HELIX(pdbid, helixid, helixclassid, initchainid, initaaid, endchainid, endaaid, comment) values ("
				  + "'" + pdbparser.m_pdbid + "'" + ", " + helixid + ", " + helixclassid + ", " + "'" + initchainid + "'" + ", "
				  + initaaid + ", " + "'" + endchainid + "'" + ", " + endaaid + ", " + "'" + comment + "'" + ")";
    pdbparser.m_db.execUpdate(update);
    
}

/* this function parses one "header"-line */
  private static void parseHeader() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
          String IDcode = pdbparser.m_line.substring(62,66),substr="";

          pdbparser.m_pdbid = IDcode;
          substr = pdbparser.m_line.substring(10,50);
          substr = substr.toLowerCase();

          if(substr.indexOf("complex") != -1)
          {
                  pdbparser.m_complex = true;
                  pdbparser.m_cause = "HEADER";
          }

          try{
                  ResultSet set = pdbparser.m_db.execQuery("select * from pdb where pdbid = '"+pdbparser.m_pdbid+"'");

                  if(set.next())
                  {
                          pdbparser.m_pdb_exists = true;
                          pdbparser.m_bad=true;
                          pdbparser.m_cause_of_badness = "PDB-id "+pdbparser.m_pdbid+" already occurs in the database!!";
                  }
                  set.close();
          }catch (SQLException e)
          {
                  System.out.println(e.getSQLState());
                  e.printStackTrace();
                  pdbparser.m_db.close();
          }

          if(!pdbparser.m_bad)  // pdb-file not valid
          {
                  String insertPDB = "insert into PDB values( '"+ pdbparser.m_pdbid +"' , '0' , '')";
                  pdbparser.m_db.execUpdate(insertPDB);
          }
  }

  /* this function parses one "title"-line */
  private static void parseTitle(){
          String substr = pdbparser.m_line.substring(0,70);

          substr = substr.toLowerCase(); // CoMpLex => complex
          if(substr.indexOf("complex") != -1)
          {
                  pdbparser.m_complex = true;
                  pdbparser.m_cause = "TITLE";
          }
  }

  /* this function parses one "remark"-line */
  private static void parseRemark(){
          String substr = pdbparser.m_line.substring(11,38);

          substr = substr.toUpperCase();
          if(substr.equals("RESOLUTION. NOT APPLICABLE."))
          {
                  pdbparser.m_bad=true;
                  pdbparser.m_cause_of_badness="Resolution. NOT APPLICABLE.";
          }
          else
          {
                  substr = pdbparser.m_line.substring(28,38);
                  substr = substr.toUpperCase();
                  if(substr.equals("ANGSTROMS."))
                  {
                          substr = pdbparser.m_line.substring(22,27);
                          float resolution = convertToReal(substr);

                          if(resolution > 2.5f)
                          {
                                  pdbparser.m_bad=true;
                                  pdbparser.m_cause_of_badness = "Resolution too high(>2.5). File is not inserted!!";
                          }
                  }
          }
  }

  /* convert a string-number to a float-number */
  private static float convertToReal(String str){
          int i,offset=10;
          float sol = 0.0f;
          boolean dot = false;

          for(i=0;i<str.length();i++)
          {
                  if(str.charAt(i)=='.' || str.charAt(i)==',')
                          dot = true;
                  else if(str.charAt(i)>='0' && str.charAt(i) <='9')
                  {
                          if(!dot) // before '.' or ','
                          {
                                  sol *= 10;
                                  sol += (int) str.charAt(i) - (int) '0';
                          }
                          else // after '.' or ','
                          {
                                  float val = (float) str.charAt(i) - (float) '0';
                                  val /= offset;
                                  sol += val;
                                  offset *= 10;
                          }
                  }
          }
          return sol;
  }

  /* convert a string-number to a int-number */
  private static int convertToInt(String str){
          int i;
          int sol = 0;

          for(i=0;i<str.length();i++)
          {
                  if(str.charAt(i)>='0' && str.charAt(i) <='9')
                  {
                          sol *= 10;
                          sol += (int) str.charAt(i) - (int) '0';
                  }
          }

          return sol;
  }

  /* this function parses one "seqres"-line */
  private static void parseSeqres() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
          int numRes, aaid = -1, serNum, start = 19;
          String insertAA = "", replace = "", aa ="";
          char chainID = pdbparser.m_line.charAt(11);

          serNum = (convertToInt(pdbparser.m_line.substring(8,10)) - 1)*13;
          numRes = convertToInt(pdbparser.m_line.substring(13,17));

          if(chainID == 'E'||chainID == 'I'||chainID == 'Z')
          {
                  pdbparser.m_complex = true;
                  pdbparser.m_cause = "SEQRES";
          }

          if(pdbparser.m_seqres.size()<=0){
                  pdbparser.m_seqres.addElement((String)"");
                  pdbparser.m_seqres_chainid.addElement((String) (chainID + ""));
          }

          replace = (String) pdbparser.m_seqres.elementAt(pdbparser.m_seqres.size()-1);
          pdbparser.m_seqres.removeElementAt(pdbparser.m_seqres.size()-1);
          pdbparser.m_seqres_chainid.removeElementAt(pdbparser.m_seqres_chainid.size()-1);
          
          for(int i = 0;i < 13;i++)
          {
                  aaid = serNum + i;
                  if(aaid < numRes)
                  {
                          aa = pdbparser.m_line.substring(start,start+3);
                          insertAA = "insert into AA(pdbid,chainid,aaid,aaname) values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+aaid+" , '"+aa+"')";
//			  System.out.println(insertAA);
                          replace += aa;
                          pdbparser.m_db.execUpdate(insertAA);
                  }
                  start += 4;// update startposition
          }

          pdbparser.m_seqres.addElement(replace);
          pdbparser.m_seqres_chainid.addElement((String) (chainID + ""));

          if(aaid >= numRes){
                  pdbparser.m_seqres.addElement((String)"");
                  pdbparser.m_seqres_chainid.addElement((String) (chainID + ""));
          }
  }

  /* handles the not-empty bufferpart at the end of the file-reading */
  private static void clearRemainingBuffers() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
          if(!pdbparser.m_pdb_exists)
                  processAtom();
          pdbparser.m_atom_lines.clear();
          pdbparser.m_atom_lines = new Vector();
  }

  /* this function parses one "atom"-line */
  private static void parseAtom() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
          String chainID = "" + pdbparser.m_line.charAt(21);

          if(pdbparser.m_current_chain.equals(""))
                  pdbparser.m_current_chain += "" + pdbparser.m_line.charAt(21);

          if(!chainID.equals(pdbparser.m_current_chain))
          {
                  if(pdbparser.m_atom_lines.size()>0)
                          processAtom();
                  pdbparser.m_current_chain = chainID;
                  pdbparser.m_atom_lines.clear();
                  pdbparser.m_atom_lines = new Vector();
          }

          pdbparser.m_atom_lines.addElement(pdbparser.m_line);
  }

  /* process atom-lines */
  private static void processAtom() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
          String line = "",alt="",name="",chain="",res="",insert = "",chainID="";
          Vector aa = new Vector(),alterations = new Vector();
          boolean found;

          if(pdbparser.m_atom_lines.size()> 0)
          {
                  line = (String) pdbparser.m_atom_lines.elementAt(0);
                  chain = "" + line.charAt(21);
                  aa.addElement(line);
                  alt = "" + line.charAt(16);
                  if(!alt.equals(" ") && !alterations.contains(alt))
                          alterations.add(alt);
          }
          pdbparser.m_current_aaid = 0;

          for(int i = 0;i < pdbparser.m_atom_lines.size() && !pdbparser.m_bad;i++)
          {
                  int atomid = 0;
                  Vector handled = new Vector();

                  found = false;
                  name = name + line.substring(17,20);

                  while(i < pdbparser.m_atom_lines.size() - 1 &&
                            !found)
                  {
                          res = line.substring(22,27);
                          line = (String) pdbparser.m_atom_lines.elementAt(i+1);

                          if(res.equals(line.substring(22,27)))
                          {
                                  alt = "" + line.charAt(16);
                                  if(!alt.equals(" ") && !alterations.contains(alt))
                                          alterations.add(alt);
                                  aa.addElement(line);
                                  i++;
                          }
                          else
                          {
                                  found = true;
                                  i--;
                          }
                  }
                  chainID = insertAtomsInDB(chainID,aa, alterations, atomid, handled);
                  updateAAStatus(chainID);
			// next amino acid in chain gets a new chance
				pdbparser.m_status = "perfect";
                  pdbparser.m_current_aaid++;
                  alterations.clear();
                  alterations = new Vector();
                  aa.clear();
                  aa = new Vector();
          }
          controlSequence(name,chain);
  }

  private static void updateAAStatus(String chainID) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
	  String updateAA = "update AA set status = "; 
	  if (pdbparser.m_status.equals("perfect"))
		  updateAA += " 'P' ";
	  if (pdbparser.m_status.equals("imperfect;rotate-ok"))
		  updateAA += " 'R' ";
	  if (pdbparser.m_status.equals("no-rotate"))
		  updateAA += " 'X' ";
      updateAA += " where pdbid = '" + pdbparser.m_pdbid + "' and aaid = " + pdbparser.m_current_aaid + " and chainid = '" + chainID + "'";
      pdbparser.m_db.execUpdate(updateAA);
  }


  /* insert atoms into the atompos- and alt-tables */
  private static String insertAtomsInDB(String chainID,Vector aa, Vector alterations, int atomid, Vector handled) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
          String alt,aa_line,insert="",atomName,nextAtomName,resName;
          float occup, x, y, z, temp;
          boolean alreadySet = false;

          if(aa.size()>0)
          {
                  aa_line = (String) aa.elementAt(0);
                  chainID = "" + aa_line.charAt(21);
          }

          for(int k = 0;k<alterations.size();k++)
          {
                  insert = "insert into ALT values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , '"+alterations.elementAt(k)+"' , 0.0 , '0')";
                  pdbparser.m_db.execUpdate(insert);
          }

          for(int j = 0;j < aa.size() && !pdbparser.m_bad;j++)
          {
                  aa_line = (String) aa.elementAt(j);
                  chainID = "" + aa_line.charAt(21);
                  alt = "" + aa_line.charAt(16);
                  occup = convertToReal(aa_line.substring(54,60));
                  x = convertToReal(aa_line.substring(30,38));
                  y = convertToReal(aa_line.substring(39,46));
                  z = convertToReal(aa_line.substring(46,54));
                  temp = convertToReal(aa_line.substring(60,66));
                  atomName = aa_line.substring(12,16);
                  resName = aa_line.substring(17,20);

                  atomName = atomName.trim();
                  checkNameValidation(atomName, resName, atomid);

                  if(alt.equals(" "))
                  {
                          if(alterations.size()>0)
                          {
                                  for(int k = 0;k<alterations.size();k++)
                                  {
                                          insert = "insert into ATOMPOS values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , "+atomid+" ,'"+alterations.elementAt(k)+"' , '"+atomName+"', "+x+","+y+","+z+" , "+ temp +" , 0,'y')";
                                          pdbparser.m_db.execUpdate(insert);
                                  }
                          }
                          else
                          {
                                  if(occup == 0 && !alreadySet)
                                          insert = "insert into ALT values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , '"+alt+"' , "+occup+" , '1')";
                                  else if(!alreadySet)
                                          insert = "insert into ALT values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , '"+alt+"' , "+occup+" , '0')";

                                  if(!alreadySet)
                                  {
                                          pdbparser.m_db.execUpdate(insert);
                                          alreadySet = true;
                                  }
                                  insert = "insert into ATOMPOS values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , "+atomid+" ,'"+alt+"' , '"+atomName+"', "+x+","+y+","+z+" , "+ temp +" , 0,'y')";
                                  pdbparser.m_db.execUpdate(insert);
                          }
                          atomid++;
                  }
                  else // alternative
                  {
                          if(!handled.contains(alt))
                          {
                                  if(occup == 0)
                                          insert = "update ALT set occup ="+occup+", manual = '1' where pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chainID +"' and aaid ="+pdbparser.m_current_aaid+" and altid = '"+alt+"'";
                                  else
                                          insert = "update ALT set occup ="+occup+", manual = '0' where pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chainID +"' and aaid ="+pdbparser.m_current_aaid+" and altid = '"+alt+"'";
                                  pdbparser.m_db.execUpdate(insert);
                                  handled.addElement(alt);
                          }
                          insert = "insert into ATOMPOS values( '"+ pdbparser.m_pdbid +"' , '"+ chainID +"' , "+pdbparser.m_current_aaid+" , "+atomid+" ,'"+alt+"' , '"+atomName+"', "+x+","+y+","+z+" , "+ temp +" , 0,'y')";
                          pdbparser.m_db.execUpdate(insert);

                          if((j+1)<aa.size())
                          {
                                  aa_line = (String) aa.elementAt(j+1);
                                  nextAtomName= aa_line.substring(12,16);
                                  if(!nextAtomName.equals(atomName))
                                          atomid++;
                          }
                  }
          }
          return chainID;
  }

  /* checks if atomname and aa-name are valid names */
  /* if the atom with id 'atomid' of amino acid 'resName' is not 'atomName', then
   * 	- if 'atomid' is smaller than the largest atomnumber needed to define rotations: you cannot rotate
   *    - if 'atomid' is bigger than ... : you can rotate, but set the status of the aa to 'r' (meaning "imperfect; but you can rotate") */
  private static void checkNameValidation(String atomName, String resName, int atomid) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
	  	String q_atom_db = "SELECT atomname FROM atomname WHERE atomid = " + atomid + " and aa = '" + resName + "'";
	  	ResultSet rs = pdbparser.m_db.execQuery(q_atom_db);
	  	if (rs.next()){
	  		String atom_db = rs.getString(1);
	  		if (!atom_db.equals(atomName)){ // atom with atomid is missing
				pdbparser.m_status = "imperfect;rotate-ok";
				pdbparser.m_cause_status = "atom with atomid " + atomid + "in aa " + resName + " (" + atom_db + ") is missing (found <" + atomName + "> instead). However, the atom is not needed for rotations.";
				String q_angleids_db = "SELECT count(*) FROM torsionangles WHERE aaname = '" + resName + "' AND (a = " + atomid + 
																										" OR b = " + atomid +
																										" OR c = " + atomid +
																										" OR d = " + atomid +
																										")";
				ResultSet rs_angles = pdbparser.m_db.execQuery(q_angleids_db);
				int num = 1;
				if (rs_angles.next())
					num = rs_angles.getInt(1);
				if (num > 0) {// atom with atomid is missing, and is needed for some angle calculation
					pdbparser.m_status = "no-rotate";
					pdbparser.m_cause_status = "atom with atomid " + atomid + " in aa " + resName + " (" + atom_db + ") is needed for rotations, but is missing (found " + atomName + " instead.)";
				}
				rs_angles.close();
			}
	  	} else { 
			pdbparser.m_status = "imperfect;rotate-ok";
			pdbparser.m_cause_status = "no atom with atomid " + atomid + " in amino acid " + resName + "!";
		}
		rs.close();
  }

  /* checks if a sequence (in the atom-section) is a part of another sequence (in the seqres-section)*/
  private static void controlSequence(String name,String chain) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
	  String seqRes="";
	  int index =-1;
	  int position = 0;
	  boolean found = false;
	  int[] result;

/*	  System.out.println("chains");
	  for(int i = 0; i < pdbparser.m_seqres_chainid.size(); i++)
	      System.out.println((String)m_seqres_chainid.elementAt(i) + ": " + (String) m_seqres.elementAt(i));
*/
	  for(int i = 0; i < pdbparser.m_seqres_chainid.size() && !found; i++)
		  if(chain.equals((String)pdbparser.m_seqres_chainid.elementAt(i))){
			  found = true;
			  position = i;
		  }

	  found = false;
	  seqRes = (String) pdbparser.m_seqres.elementAt(position);
	  index = seqRes.indexOf(name);


	  if(index > 0)
		  updateAAID(chain, index);

	  if(index < 0)
	  {
		  result = alignment.align(seqRes,name);

		  if(result != null)
			  updateAAID(chain,result);
		  else{
//		      System.out.println("Alignment failure");
			  pdbparser.m_bad=true;
			  pdbparser.m_cause_of_badness = "Sequence of amino acids in atom section does not match sequence of amino acids in seqres section!\n" + "sequence in atom = " + name;
		  }
	  }
  }

  /* updates the aaid-values in the schemas "alt" and "atompos" if necessary */
  private static void updateAAID(String chain, int index) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
          index = index / 3;
//	  System.out.println("Index:" + index);
          Vector aaids = new Vector();

          try{
		  ResultSet resset = pdbparser.m_db.execQuery("select distinct aaid from alt where pdbid = '"+ pdbparser.m_pdbid +"' order by aaid desc");

                  while(resset.next())
                          aaids.addElement(resset.getString(1));
                  resset.close();
          }catch (SQLException e)
          {
                  System.out.println(e.getSQLState());
                  e.printStackTrace();
                  pdbparser.m_db.close();
          }

	  if(index > 0){
          for(int m = 0;m <aaids.size();m++)
	  {
                  String update = "insert into alt(pdbid,chainid,aaid,altid,occup,manual) select pdbid,chainid,aaid +"+index+",altid,occup,manual from alt where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
 //                 System.out.println(update);
		  pdbparser.m_db.execUpdate(update);
                  update = "insert into atompos(pdbid,chainid,aaid,altid,atomid,atomname,x,y,z,temp,version,lastversion) select pdbid,chainid,aaid +"+index+",altid,atomid,atomname,x,y,z,temp,version,lastversion from atompos where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
                  update = "delete from atompos where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
                  update = "delete from alt where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
          }
	  }
  }

  /* updates the aaid-values in the schemas "alt" and "atompos" if necessary */
  private static void updateAAID(String chain, int[] result) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
          int index = 0;
          Vector aaids = new Vector();

          try{
		  ResultSet resset = pdbparser.m_db.execQuery("select distinct aaid from alt where pdbid = '"+ pdbparser.m_pdbid +"' and chainid = '" + chain + "' order by aaid desc");

                  while(resset.next())
                          aaids.addElement(resset.getString(1));
                  resset.close();
          }catch (SQLException e)
          {
                  System.out.println(e.getSQLState());
                  e.printStackTrace();
                  pdbparser.m_db.close();
          }

	  if(aaids.size() != result.length){
        	  pdbparser.m_bad=true;
			  pdbparser.m_cause_of_badness = "Sequence of amino acids in atom section does not match sequence of amino acids in seqres section!\n";
          }
          else {
          for(int m = 0;m <aaids.size();m++)
          {
	      index = result[aaids.size() - m - 1] - (aaids.size() - m - 1);
	      if(index > 0){
                  String update = "insert into alt(pdbid,chainid,aaid,altid,occup,manual) select pdbid,chainid,aaid +"+index+",altid,occup,manual from alt where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
                  update = "insert into atompos(pdbid,chainid,aaid,altid,atomid,atomname,x,y,z,temp,version,lastversion) select pdbid,chainid,aaid +"+index+",altid,atomid,atomname,x,y,z,temp,version,lastversion from atompos where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
                  update = "delete from atompos where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
                  update = "delete from alt where aaid ="+aaids.elementAt(m)+" and pdbid = '"+ pdbparser.m_pdbid +"' and chainid ='"+ chain +"'";
                  pdbparser.m_db.execUpdate(update);
	      }
          }
	  }
  }
  
  public static void main(String[] args) throws Exception{
	  String[] output = new String[1];
	  pdbparser.readFile(args[0], output);
	  System.out.println(output[0]);
	  //pdbparser.readDirectory(args[0]);
  }
  
  private static void readDirectory(String dir) throws Exception {
	  Process p = Runtime.getRuntime().exec("ls " + dir); 
	  BufferedReader files = new BufferedReader(new InputStreamReader(p.getInputStream()));
	  String file;
	  int count = 0;
	  int exc_count = 0;
	  int dubbel = 0, resolutie = 0, substring = 0, file_error = 0;
	  String[] output = new String[1];
	  while ((file = files.readLine()) != null){
		  try {
			  count++;
			  System.out.print(count + "... " + file + " ");
			  pdbparser.readFile(dir + "/" + file, output);
			  if (pdbparser.m_bad){
				  if (pdbparser.m_cause_of_badness.startsWith("PDB-id"))
					  dubbel++;
				  else if (pdbparser.m_cause_of_badness.startsWith("Resolution") || pdbparser.m_cause_of_badness.startsWith("Slechte"))
					  resolutie++;
				  else if (pdbparser.m_cause_of_badness.startsWith("Sequence"))
					  substring++;
				  else if (pdbparser.m_cause_of_badness.startsWith("File error"))
					  file_error++;
			  }
		  } catch (Exception e) {
			  exc_count++;
		  }
		  System.out.println("total: "+ count + ";\n dubbels: " + dubbel + ",\n resolutie: " + resolutie + ",\n substring: " + substring +",\n file error: " + file_error + ";\n exceptions: " + exc_count);
	  }
	  files.close();
		
//	  System.out.println("total: "+ count + ";\n dubbels: " + dubbel + ",\n resolutie: " + resolutie + ",\n substring: " + substring +",\n file error: " + file_error + ";\n exceptions: " + exc_count);
  }
}
