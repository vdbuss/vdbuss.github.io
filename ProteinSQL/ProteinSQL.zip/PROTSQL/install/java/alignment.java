import java.util.HashMap;

public class alignment {

	public final static int OPEN_GAP = 3;
	public final static int EXTEND_GAP = 1;
	public final static int MISMATCH = 1000;
	public final static int SCORE = 0;
	public final static int SCORE_H = 1;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kort, lang;
		
		for(int i = 0; i < 100; i++){
			lang = generateString((int) (Math.random()*200));
			kort = generateString((int)(Math.random()*50));
			System.out.println("Aligneren van " + lang + " en " + kort);
			printAlignment(lang,kort,align(lang,kort));
			System.out.println("______________________");
		}
			
		
		System.out.println("GEDAAN");
		
		
	}
	
	public static String generateString(int length){
		
		String result = "";
		
		while(length > 0){
			result += (char) (65 + (int)(Math.random() * 26));
			length--;
		}
		
		return result;
	}
	
	public static int[] align(String seqres, String atom){
		int[] result;
		int[][][] score;
		int[][][] scoreH;
		//boolean[][][] direction = new boolean[seqres.length() + 1][atom.length() + 1][2];
		int row, col;
		
		seqres = convert(seqres);
		atom = convert(atom);
		
		result = new int[atom.length()];
		score = new int[seqres.length() + 1][atom.length() + 1][2];
		scoreH = new int[seqres.length() + 1][atom.length() + 1][2];

		
		if(atom.length() > seqres.length()) //seqres sequence must be the longest
			return null;
		
		// Fill the matrix. Atom string is on top, Seqres string to the left.	
		for(col = 1; col <= atom.length(); col++){
			score[0][col][0] = -MISMATCH;
			scoreH[0][col][0] = -MISMATCH;
		}
		
		for(row = 1; row <= seqres.length(); row++){
			for(col = 1; col <= atom.length(); col++){
				scoreH[row][col][0] = Math.max(score[row-1][col][0] - OPEN_GAP, scoreH[row-1][col][0] - EXTEND_GAP);
				/*if(score[row-1][col][0] - OPEN_GAP >= scoreH[row-1][col][0] - EXTEND_GAP)
					scoreH[row][col][1] = SCORE;
				else
					scoreH[row][col][1] = SCORE_H;*/
				
				if(seqres.charAt(row-1) == atom.charAt(col-1)){
					score[row][col][0] = Math.max(scoreH[row][col][0],score[row-1][col-1][0]);
					if(scoreH[row][col][0] >= score[row-1][col-1][0])
						score[row][col][1] = SCORE_H;
					else
						score[row][col][1] = SCORE;
				}
				else{
					score[row][col][0] = Math.max(scoreH[row][col][0],score[row-1][col-1][0] - MISMATCH);
					if(scoreH[row][col][0] >= score[row-1][col-1][0] - MISMATCH)
						score[row][col][1] = SCORE_H;
					else
						score[row][col][1] = SCORE;
				}
			}
			
		}	
		
		/*printMatrix(score);
		System.out.println();
		printMatrix(scoreH);*/
		
		// Finally, fill result table
		boolean inHor = false;
		int max = score[0][atom.length()][0], maxIndex = 0;
		for(row = 1; row <= seqres.length(); row++)
			if(score[row][atom.length()][0] > max){
				max = score[row][atom.length()][0];
				maxIndex = row;
			}
		
		// No alignment found
		if(max <= -MISMATCH)
			return null;
	
		
		row = maxIndex;		
		//System.out.println(row + " " + score[row][atom.length()][1]);
		
		col = atom.length();
		while(col > 0 && row >= 0){
			if(score[row][col][1] == SCORE){
				result[col-1] = row - 1;
				row--;
				col--;
			}
			else{
				row--;
			}
		}
		
		//printAlignment(seqres,atom,result);
		return result;
	}
	
	public static void printMatrix(int[][][] matrix){
		int i,j;
		
		for(i = 0; i < matrix.length; i++){
			for(j = 0; j <matrix[i].length;j++){
				System.out.print(matrix[i][j][0]
				                              + "\t");
			}
			System.out.println();
		}
	}
	
	public static void printAlignment(String seqres,String atom, int[] result){
		int atomIndex = 0;
		
		/*for(int i = 0; i < atom.length(); i++)
			System.out.print(result[i] + " ");
		System.out.println("\n");*/
		
		if(result != null){
		
		System.out.println(seqres);

		

		
		for(int i = 0; i < seqres.length();i++){
			if(atomIndex < atom.length() && result[atomIndex] == i){
				System.out.print(atom.charAt(atomIndex));
				atomIndex++;
			}
			else
				System.out.print("-");
		}
		System.out.println();
		}
	}
	
	public static String convert(String sequence){
		String ret = "",aa;
		HashMap map = new HashMap(20);
		map.put("ALA","A");
		map.put("ARG","B");
		map.put("ASN","C");
		map.put("ASP","D");
		map.put("CYS","E");
		map.put("HIS","F");
		map.put("GLN","G");
		map.put("GLU","H");
		map.put("GLY","I");
		map.put("ILE","J");
		map.put("LEU","K");
		map.put("LYS","L");
		map.put("MET","M");
		map.put("SER","N");
		map.put("PHE","O");
		map.put("PRO","P");
		map.put("THR","Q");
		map.put("TRP","R");
		map.put("TYR","S");
		map.put("VAL","T");
		
		if(sequence.length() % 3 != 0)
			return "";
		else{
			while(sequence.length() > 2){
				aa = sequence.substring(0,3);
				sequence = sequence.substring(3);
				if(!map.containsKey(aa))
					ret += 'U';
				else
					ret += (String) map.get(aa);
			}
		}
		
		return ret;
		
	}
	
}
	