db2 connect to {{DATABASE-NAME}}
db2 set current schema = '{{SCHEMA-NAME}}'
{{JAVA-COMPILER}}/javac dbconnection2.java
{{JAVA-COMPILER}}/javac -classpath $CLASSPATH:./Jama-1.0.1.jar components.java
{{JAVA-COMPILER}}/jar -xf Jama-1.0.1.jar
{{JAVA-COMPILER}}/jar -cvf princip.jar dbconnection2.class components.class principresult.class Jama
db2 "call sqlj.install_jar('file:{{WORKING-DIRECTORY}}/install/java/princip.jar', 'PRINCIPAL')"
{{JAVA-COMPILER}}/javac Angles.java
{{JAVA-COMPILER}}/jar -cvf Anglesj.jar Angles.class 
db2 "call sqlj.install_jar('file:{{WORKING-DIRECTORY}}/install/java/Anglesj.jar', 'ANGLESJARJ')"
{{JAVA-COMPILER}}/javac dbconnection2.java
{{JAVA-COMPILER}}/javac alignment.java
{{JAVA-COMPILER}}/javac pdbparser.java
{{JAVA-COMPILER}}/jar -cvf pdbparser.jar pdbparser.class dbconnection2.class alignment.class
db2 "call sqlj.install_jar('file:{{WORKING-DIRECTORY}}/install/java/pdbparser.jar', 'PDBREADER')"
db2 "call sqlj.refresh_classes()"
db2 connect reset