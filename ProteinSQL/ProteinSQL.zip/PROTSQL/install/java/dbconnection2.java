import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import com.ibm.db2.jcc.*;

/* klasse die zorgt voor de connectie met database en het uitvoeren van queries. */
class dbconnection2 {

    /* database-instellingen*/
    private static String m_userid = "{{USER-NAME}}";
    private static String m_psswd = "{{PASSWORD}}";
    private static String m_dbname = "{{DATABASE-NAME}}";
    private static String m_server = "{{DATABASE-SERVER}}";
    private static String m_port = "{{PORT}}";
    private static String m_schema = "{{SCHEMA-NAME}}";

    /* members */
    private int m_count;
    private boolean m_open;
    private Connection m_connect;

    public boolean isOpen(){
            return m_open;
    }

    public dbconnection2() {
	    m_count = 0;
		try {
			open();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

	/* connectie openen */
    public void open() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
	    Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();

	    String url = "jdbc:db2://" + m_server + ":" + m_port + "/" + m_dbname;

	    m_count = 0;
	    m_connect = DriverManager.getConnection(url,m_userid,m_psswd);
	    m_connect.setAutoCommit(false);
	    m_open = true;
	    execUpdate("SET CURRENT SCHEMA = '"+m_schema.toUpperCase()+"'");
	}

    /* query uitvoeren */
    public ResultSet execQuery(String q) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		Statement stmt=null;
		ResultSet rs= null;

		if(m_count>1000)
		{
			change();
			m_count = 0;
		}
		m_count++;
	    stmt = m_connect.createStatement();
	    rs = stmt.executeQuery(q);
		return rs;
    }

    /* update-query uitvoeren (insert,delete,update) */
    public int execUpdate(String q) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	Statement stmt = null;
    	int t = -1;

		if(m_count>1000)
		{
			change();
			m_count = 0;
		}
		m_count++;
		stmt = m_connect.createStatement();
		t = stmt.executeUpdate(q);
    	return t;
    }

    /* connectie sluiten */
    public void close(){
	    try {
	    	m_connect.commit();
	    	m_connect.close();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    }
	    m_open = false;
    }

    /* sluiten (indien open) en vervolgens (her)openen*/
    public void change() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
    	if(m_open)
    		close();
    	open();
    }
}







