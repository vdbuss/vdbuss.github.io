import java.text.NumberFormat;
import java.util.Vector;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.sql.*;
import Jama.Matrix;
import Jama.EigenvalueDecomposition;
import COM.ibm.db2.app.*;

class principresult {
	
	Vector pointsX, pointsY, pointsZ;
	public Matrix eigvect;
	public Matrix eigvalsm;
	public char chainid;
	public int AAid;
	public char altid;
	
	public principresult(char chainid,int AAid,char altID){
		pointsX = new Vector();
		pointsY = new Vector();
		pointsZ = new Vector();
		this.chainid = chainid;
		this.AAid = AAid;
		this.altid = altID;
	}
	
	public int numPoints() {
		return pointsX.size();
	}
	
	public void addPoint(double x, double y, double z){
		pointsX.add(new Double(x));
		pointsY.add(new Double(y));
		pointsZ.add(new Double(z));
	}
	
	public void calculate() throws Exception{
		// fictieve puntenset, n punten, dimensie p
		int n = pointsX.size();
		int p = 3;
		double[][] vals = new double[n][p];
		
		for(int i = 0; i < n; i++){
			vals[i][0] = ((Double)pointsX.elementAt(i)).doubleValue();
			vals[i][1] = ((Double)pointsY.elementAt(i)).doubleValue();
			vals[i][2] = ((Double)pointsZ.elementAt(i)).doubleValue();
		}
		

		// trek van elke kolom het gemiddelde af
		double[] gem = new double[p];
		for (int i=0; i<p; i++){
			double sum = 0.0;
			for (int j=0; j<n; j++)
				sum += vals[j][i];
			gem[i] = sum / n;
		}
		for (int i=0; i<p; i++)
			for (int j=0; j<n; j++)
				vals[j][i] -= gem[i];


		// bereken de principale componenten
		// van de puntenset door de eigenwaarden en eigenvectoren
		// van de matrix transpose(vals) x vals te berekenen.
		Matrix m = new Matrix(vals);
		Matrix mtranspose = m.transpose();
		m =  mtranspose.times(m);
		EigenvalueDecomposition eigdec = new EigenvalueDecomposition(m);
		double[] eigvals = eigdec.getRealEigenvalues();
		eigvect = eigdec.getV();
		eigvalsm = new Matrix(eigvals, 1);
	}
}

public class components extends UDF{
	private Vector results;
	
	public void calculateComponents(String inPDBid, String outchainid, int outAAid, String outAltid, double outV1X, double outV1Y, double outV1Z, double outLambda1, double outV2X, double outV2Y, double outV2Z, double outLambda2, double outV3X, double outV3Y, double outV3Z, double outLambda3){
	  dbconnection2 m_db = null;
	  try{
	   switch (getCallType()){
		case SQLUDF_TF_FIRST:
               // do initialization which is independent of input parameters
               break;
            case SQLUDF_TF_OPEN:
		   char chainid = '?';
               int AAid = -1;
               char altid = '?';
		   principresult result = null;
		   results = new Vector();		   
               m_db = new dbconnection2();

		   ResultSet resset = m_db.execQuery("select chainid,aaid,altid,atomid,x,y,z from atomposlast where pdbid='" + inPDBid + "' AND atomid > 3 ORDER BY chainid,aaid,altid,atomid");
		   while(resset.next()){
           		// Beginnen aan nieuw aminozuur;
           		if(resset.getString(1).charAt(0) != chainid || resset.getInt(2) != AAid || resset.getString(3).charAt(0) != altid){
           			chainid = resset.getString(1).charAt(0);
				AAid = resset.getInt(2);
				altid = resset.getString(3).charAt(0);
				result = new principresult(chainid, AAid, altid);
           			results.add(result);
           		}
           		result.addPoint(resset.getDouble(5),resset.getDouble(6),resset.getDouble(7));
		   }
		   resset.close(); 
		   m_db.close();    

               break;
            case SQLUDF_TF_FETCH:
		   if (results.size() == 0)
               {   // Set end-of-file signal and return
                   setSQLstate ("02000");
               }
		   else
               {   // Set the current output row and increment the row number
            	principresult res = (principresult) results.elementAt(0);
            	results.removeElementAt(0);
            	res.calculate();
            	String chainString = "" + res.chainid;
		   	String altString = "" + res.altid;

			if (needToSet (2)) set (2, chainString);
                  if (needToSet (3)) set (3, res.AAid);
                  if (needToSet (4)) set (4, altString);
                  if (needToSet (5)) set (5, res.eigvect.get(0,0));
			if (needToSet (6)) set (6, res.eigvect.get(0,1));
			if (needToSet (7)) set (7, res.eigvect.get(0,2));
			if (needToSet (8)) set (8, res.eigvalsm.get(0,0));
			if (needToSet (9)) set (9, res.eigvect.get(1,0));
			if (needToSet (10)) set (10, res.eigvect.get(1,1));
			if (needToSet (11)) set (11, res.eigvect.get(1,2));
			if (needToSet (12)) set (12, res.eigvalsm.get(0,1));
			if (needToSet (13)) set (13, res.eigvect.get(2,0));
			if (needToSet (14)) set (14, res.eigvect.get(2,1));
			if (needToSet (15)) set (15, res.eigvect.get(2,2));
			if (needToSet (16)) set (16, res.eigvalsm.get(0,2));
		   }
               break;
            case SQLUDF_TF_CLOSE:
               break;
            case SQLUDF_TF_FINAL:
               break;
         }	
	 }catch(Exception e){
	  	if(m_db != null){
	      	try{	
				m_db.close();	          
			} catch(Exception e1){}
	  	}
	 }
	}
}
