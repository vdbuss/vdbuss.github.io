db2 connect to {{DATABASE-NAME}}
db2 set current schema = '{{SCHEMA-NAME}}'
db2 set current function path = current function path, {{SCHEMA-NAME}}
db2 -td@ -f computeTorsionAngle.db2
db2 -td@ -f rotateAtomXYZ.db2
db2 -td@ -f readFile.db2
db2 -tf length.db2
db2 -tf distance.db2
db2 -tf dist.db2
db2 -tf simil.db2
db2 -tf AADistance.db2
db2 -tf AtomBonding.db2
db2 -tf StericClash.db2
db2 -td@ -f reset.db2
db2 -td@ -f rollback.db2
db2 -td@ -f normalizeAngle.db2
db2 -tf computeChi.db2
db2 -tf computeChiVersion.db2
db2 -tf computePhi.db2
db2 -tf computePsi.db2
db2 -tf ListRotations.db2
db2 -tf Calculate_angles.db2
db2 -tf getstatus.db2
db2 -tf getResName.db2
db2 -td@ -f rotate.db2
db2 -td@ -f check_flexibility.db2
db2 -tf principal.db2
db2 connect reset