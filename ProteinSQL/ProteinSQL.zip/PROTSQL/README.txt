Welcome to the Protein SQL system. This document describes the
contents of this directory; how the Protein SQL system can be
installed and removed; and what the requirements for the system are.

CONTENTS
--------

This directory contains 2 subdirectories, "install" and
"uninstall". The install directory is further divided into a "java"
and "sql" subdirectory. The "sql" directory contains the statements to
create the database (createDB.sql) and the functions and procedures
(*.db2 files). The script createfunctions.sh creates the database and
the functions and procedures. The "java" directory contains all Java
code of the system. The script installJava.sh contains the Java
compilation instructions and statements to install the jar files.


REQUIREMENTS
____________
- A Unix based system
- DB2 V 9
- DB2 Java compiler

The system has only been tested with the above requirements. However,
it only uses java and functionalities of DB2. Therefore, it should
also be possible to for instance install it on a windows
system. However, no guarantees are given.

The application heap size of the database should have a value of at
least 1024. To update the value of this parameter, use the command
update db config using applheapsz 1024

INSTALLATION
____________

Step 1: adjusting the files

Some of the files needed in the installation contain a number of
"parameters" which depend on your system and your installation. These
parameters are the following:

{{DATABASE-NAME}} : The name of the database. We use "protsql".
{{SCHEMA-NAME}} : The name of the schema. We use "PROTSQL". Use only uppercase letters here!
{{DATABASE-SERVER}} : The server on which the database is located. We use "localhost".
{{PORT}} : The port number on which the database server is installed. We use 50002.
{{USER-NAME}} : Your user name on the database system.
{{PASSWORD}} : Your password on the database system.
{{DB2-INSTALLATION-SQLLIB}} : The path to the sqllib folder in your
db2 installation. In our case "/scratch/db2/db2iexp/sqllib"
{{JAVA-COMPILER}} : The path to the IBM java compiler. In our case "/opt/ibm/db2/V9.1/java/jdk32/bin"
{{WORKING-DIRECTORY}} : The full path to the PROTSQL directory that is the result of unpacking the zip file ProteinSQL.zip. In our case "/home/username/PROTSQL".

These parameters occur in the files createDB.sql, installJava.sh,
createfunctions.sh, and dbconnection2.java, and can be filled in by
using the search-replace tool of your favourite text editor

Step 2: installation

Go to the install directory (specified by
{{WORKING-DIRECTORY}}/install) and execute the installation script by
the command: 
. createProteinSQL.sh



REMOVAL
_______

Step 1: adjusting the files

The removal files contain the same parameters as the ones for
the installation. These files are dropfunctions.sh, uninstallJava.sh,
and dropDB.sql. Again, replace these parameters by your values by
using search-replace.

Step 2: removal Go to the uninstall directory (specified by
{{WORKING-DIRECTORY}}/uninstall) and execute the removal script by the
command: 
. removeProteinSQL.sh




