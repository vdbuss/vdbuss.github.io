db2 connect to {{DATABASE-NAME}}
db2 set current schema = '{{SCHEMA-NAME}}'
db2 "call sqlj.remove_jar('PDBREADER')"
db2 "call sqlj.remove_jar('ANGLESJARJ')"
db2 "call sqlj.remove_jar('PRINCIPAL')"
db2 "call sqlj.refresh_classes()"
db2 connect reset