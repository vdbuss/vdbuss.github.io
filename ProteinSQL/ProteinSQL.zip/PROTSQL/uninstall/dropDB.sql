connect to {{DATABASE-NAME}}
set current schema = '{{SCHEMA-NAME}}'
drop view sheet
drop table strand
drop table turn
drop table helixclass
drop table helix
drop table chi
drop table check_flex
drop view atomposlast
drop view chain
drop table waalsdist
drop table bondlengths
drop table torsionangles
drop table atomname
drop table atompos
drop table alt
drop table aa
drop table pdb
drop schema {{SCHEMA-NAME}} restrict
connect reset