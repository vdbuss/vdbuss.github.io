. dropfunctions.sh
. uninstallJava.sh
db2 -f dropDB.sql