
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 *
 * Helpt bij het lezen van en schrijven naar de scratchpad. Deze klasse is
 * verwacht een specifieke inhoud op de scratchpad, zoals een integer teller,
 * en is daarom niet general purpose.
 */
public class TableScratchPad {

    // Input:
    private byte[] scratchpad;
    // Momenteel slaan we enkel een tellertje op in de scratchpad.
    private int counter;

    /**
     * Gebruik deze constructor om mogelijk data te lezen van een eerder
     * geïnitialiseerde scratchpad.
     * 
     * @param scratchpad
     * @param read indien true wordt de scratchpad gelezen
     */
    public TableScratchPad(byte[] scratchpad, boolean read) throws IOException {
        this.scratchpad = scratchpad;

        // Lees de teller
        if (read) {
            DataInputStream dataIn = new DataInputStream(new ByteArrayInputStream(scratchpad));
            this.counter = dataIn.readInt();
        } else {
            counter = 0;
        }
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    /**
     * Sla de wijzigingen op in de bytes.
     */
    public byte[] writeBytes() throws IOException {
        // Eerst serialiseren we de gegevens naar een byte array outputstream
        ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
        DataOutputStream dataOut = new DataOutputStream(bytesOut);
        dataOut.writeInt(this.counter);

        // Nu kopiëren we de gegevens over naar de scratchpad
        System.arraycopy(bytesOut.toByteArray(), 0, scratchpad, 0, bytesOut.size());

        return scratchpad;
    }

}
