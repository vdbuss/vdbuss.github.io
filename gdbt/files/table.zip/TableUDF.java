
import COM.ibm.db2.app.UDF;

/**
 * Deze klasse zorgt voor de interface tussen Java hulpklassen en DB2.
 *
 */
public class TableUDF extends UDF {

    // Het echte algoritmische werk gebeurt in de klasse TableGen. Per instantie
    // van de klasse TableUDF (deze klasse) houden we zo'n TableGen object bij.
    TableGen tableGen;

    TableUDF() {
        tableGen = new TableGen();
    }

    public void makeTable(String input, int id, String word) throws Exception {
        // Enkel de input-string is belangrijk omdat de output-argumenten
        // gewoon dummies zijn.
        tableGen.dispatcher(getCallType(), input, this);
    }


}
