
import COM.ibm.db2.app.UDF;

/**
 * Deze klasse test de klasse TableGen. We bootsen hier de calls na die een echte
 * db2 database zou doen. We moeten daartoe methods overriden omdat
 * anders er java.lang.UnsatisfiedLinkErrors worden gegooid. Dat komt omdat
 * een echte connectie met db2 afwezig is hier.
 *
 */
public class TableTester extends UDF {

    // De scratchpad die we doorgeven aan de TableGen klasse.
    byte []scratchpad;

    // De kolommen van één rij:
    int id;
    String word;

    // Geeft aan of alle rijen zijn gegenereerd of niet.
    boolean done;

    public TableTester() {
        // Normaal gezien weet de echte database hoe groot de scratchpad
        // is gedeclareerd via een apart scriptje. Dat weten we hier niet en
        // daarom nemen we een arbitraire scratchpad-grootte:
        scratchpad = new byte[1024];

        id = -1;
        word = "";
        done = false;
    }

    @Override
    public byte[] getScratchpad() throws Exception {
        return scratchpad;
    }

    @Override
    public void setScratchpad(byte[] bytes) throws Exception {
        System.arraycopy(bytes, 0, this.scratchpad, 0, bytes.length);
    }

    @Override
    public void set(int i, String s) throws Exception {
        // We hoeven niet te kijken naar de index omdat enkel de
        // tweede kolom van de output-rij een string kan zijn.
        word = s;
    }

    @Override
    public void set(int i, int v) throws Exception {
        // We hoeven niet te kijken naar de index omdat enkel de
        // eerste kolom van de output-rij een integer kan zijn.
        id = v;
    }

    @Override
    public void setSQLstate(String string) throws Exception {
        if(string.equals("02000"))
            // Tabel-constructie is klaar.
            done = true;
    }

    public void printRow() {
        System.out.println("" + id + " " + word);
    }

    public boolean isDone() {
        return done;
    }

    //=====================================================
    public static void main(String[] args) {

        TableGen t = new TableGen();
        
        try {
            TableTester db2 = new TableTester();

            // OPEN
            t.dispatcher(UDF.SQLUDF_TF_OPEN, "4m1a9n5d3f", db2);

            while(true) {
                // FETCH
                t.dispatcher(UDF.SQLUDF_TF_FETCH, null, db2);

                if(!db2.isDone())
                    db2.printRow();
                else
                    break;
            }

            // CLOSE
            t.dispatcher(UDF.SQLUDF_TF_CLOSE, null, db2);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
