
import COM.ibm.db2.app.UDF;
import java.util.regex.Pattern;

/**
 * Deze klasse implementeert een Java external function die een tabel
 * genereert.
 *
 * Een teller slaan we op op de scratchpad en een String als member variabele.
 * Op die manier illustreren we beide manieren om informatie te onthouden tussen
 * verschillende oproepen van db2 door.
 *
 */
public class TableGen {
    //================================================================

    // De reguliere expressie waaraan de input string moet voldoen.
    private static final Pattern pattern = Pattern.compile("(\\d\\w)+");
    // Belangrijk: we mogen ook instance member-variabelen gebruiken.
    String inputString;

    //--------------------------------------------------------------------------
    /**
     * Een nieuw Java object wordt gealloceerd per referentie van de tabel-functie
     * in een SQL statement.
     */
    public TableGen() {
        inputString = null;
    }


    /**
     * Deze hulpfunctie gaat na in welke fase van het protocol we zitten en roept
     * de nodige hulp-functies op die daarmee overeenkomen.
     *
     * @param callType in welke fase van het protocol we zitten.
     * @param inputString
     * @param db2 stelt de interface met DB2 voor
     * @throws Exception
     */
    public void dispatcher(int callType, String inputString, UDF db2) throws Exception {

        TableScratchPad pad = null;

        switch (callType) {

            //-----------------------------
            case UDF.SQLUDF_TF_FIRST:
                // Doe niets.
                break;
            //-----------------------------
            case UDF.SQLUDF_TF_OPEN:
                // We lezen nog niets van het niet-geïnitialiseerde scratchpad.
                pad = new TableScratchPad(db2.getScratchpad(), false);
                openHelper(inputString, pad, db2);
                db2.setScratchpad(pad.writeBytes()); // doorgeven aan db2
                break;
            //-----------------------------
            case UDF.SQLUDF_TF_FETCH:
                // Nu mogen we wel lezen van de scratchpad omdat deze geïnitialiseerd
                // is. De input-string hebben we reeds onthouden in de member-variabele.
                pad = new TableScratchPad(db2.getScratchpad(), true);

                // Zolang er nog nieuwe rijen gegenereerd worden geven we die
                // door aan db2.
                RowData row = fetchHelper(pad);
                if (row != null) {
                    db2.set(2, row.getId());            // doorgeven aan db2
                    db2.set(3, row.getWord());          // doorgeven aan db2
                    db2.setScratchpad(pad.writeBytes());// doorgeven aan db2
                }
                else {
                    this.endTableConstruction(db2);
                }

                break;
            //-----------------------------
            case UDF.SQLUDF_TF_CLOSE:
                // We hebben geen belangrijke resources gealloceerd, dus doe
                // niets. Hier zou je in principe files of netwerk-
                // connecties kunnen afsluiten.
                break;
            //-----------------------------
            case UDF.SQLUDF_TF_FINAL:
                // Doe niets.
                break;
        }       
    }

    /**
     * Hulpfunctie die wordt opgeroepen bij de initialisatie van de tabel.
     * Hier worden nog geen rijen gegenereerd.
     *
     * @param inputString
     * @param pad niet-geïnitialiseerde scratchpad
     */
    private void openHelper(String inputString, TableScratchPad pad, UDF db2) throws Exception {
        // Nu krijgen we de input binnen. Controleer of deze geldig is.

        if (!pattern.matcher(inputString).matches()) {
            db2.setSQLstate("38XXX");
            db2.setSQLmessage("Input string does not satisfy syntax");
            this.inputString = null;            
        } else {
            // Sla de teller op van het hoeveelste cijfer-letter paar
            // we hebben afgewerkt. Dit opslaan doen we op het scratchpad
            // omdat een teller een constante hoeveelheid geheugen in
            // beslag neemt (32 bits bijvoorbeeld).
            pad.setCounter(0); // zero-based counter

            // De input-string daarentegen slaan we op in de member-variabele.
            // Dat doen we omdat deze string mogelijk groter is dan het
            // scratchpad.
            this.inputString = inputString;
        }
    }

    /**
     * Hulpfunctie. Deze functie parst de input-string en genereert de volgende
     * rij  van de tabel.
     *
     * @param pad een geïnitialiseerd scratchpad
     * @return
     * @throws Exception
     */
    public RowData fetchHelper(TableScratchPad pad) throws Exception {

        RowData generatedRow = null;

        if (inputString == null) {
            return null;
        }

        // De counter zit op het scratchpad.
        int counter = pad.getCounter();

        if (counter * 2 >= inputString.length()) {
            // Volledige string is afgewerkt.
            return null;
        }

        // Construeer output woord
        int digit = Character.digit(inputString.charAt(counter * 2), 10);
        char letter = inputString.charAt(counter * 2 + 1);

        StringBuilder strBuilder = new StringBuilder();
        for (int i = 0; i < digit; ++i) {
            strBuilder.append(letter);
        }

        generatedRow = new RowData(counter + 1, strBuilder.toString());

        // Onthoud de volgende waarde van de counter op de scatchpad:
        pad.setCounter(counter + 1);

        return generatedRow;
    }

    /**
     * Deze hulpfunctie roepen we op als we aan db2 willen duidelijk maken dat
     * de tabel klaar is.
     *
     * @throws Exception
     */
    private void endTableConstruction(UDF db2) throws Exception {
        // Indien we klaar zijn met de tabel-constructie moeten
        // we verplicht de volgende code opgeven (zie db2 html handleiding):
        db2.setSQLstate("02000");
    }
}
