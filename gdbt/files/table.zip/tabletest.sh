db2 connect to gdbt

db2 "select * from table(strgen('2a3c2d5f'))"