db2 connect to gdbt

db2 "drop table r"

db2 "create table r(a double, b double)"

db2 "insert into r values (1,2),(2,3),(3,1),(3,3)"

db2 "select smaller1(a,b) from r"

db2 "select smaller2(a,b) from r"

db2 "drop table r"