

import java.sql.SQLException;

public class Scalar1 {

    /**
     * Parameter style JAVA
     * @param a
     * @param b
     * @return 1 indien a kleiner is dan b en 0 anders
     * @throws SQLException
     */
    public static int smaller1(double a, double b) throws SQLException {
        if(a < b)
            return 1;
        else
            return 0;
    }
}

