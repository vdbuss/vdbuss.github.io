# compileer de code
rm *.class
rm *.jar
javac Scalar1.java
javac Scalar2.java

# bundelen in jar file
jar -cvf extfunscalar.jar Scalar1.class Scalar2.class

db2 connect to gdbt

# oude functies uit db2 verwijderen
db2 -tvf scalarunregister.db2

# oude jar file wegdoen
db2 "CALL sqlj.remove_jar('extfunscalar')"

# OPGELET: vul op de plaats van de ... jouw eigen account naam in en pas ook indien nodig het pad naar
# de jar file aan indien deze niet op het hoogste niveau van jouw home directory staat.
db2 "call sqlj.install_jar('file:/home/.../extfunscalar.jar', 'extfunscalar')"

# Als de oude versie nog geladen was, ververs dan de class files:
db2 "call sqlj.refresh_classes()"

# functies declareren
db2 -tvf scalarregister.db2

db2 commit