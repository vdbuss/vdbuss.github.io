
import COM.ibm.db2.app.UDF;

public class Scalar2 extends UDF {


    /**
     * Parameter style DB2GENERAL
     * @param a
     * @param b
     * @param answer wordt 1 als a kleiner is dan b en 0 anders.
     * @throws Exception
     */
    public void smaller2(double a, double b, int answer) throws Exception {

        switch (getCallType()) {
            case UDF.SQLUDF_FIRST_CALL:
            // Hier eventueel een dure resource openen. In dit voorbeeld
            // is dat niet nodig.

            case UDF.SQLUDF_NORMAL_CALL:

                // parameter a heeft index 1
                // parameter b heeft index 2
                // parameter answer heeft index 3

                if (a < b) {
                    set(3, 1);
                } else {
                    set(3, 0);
                }

                break;
        }
    }

    @Override
    public void close() throws Exception {
        // Deze method wordt door DB2 aangeroepen als we de "FINAL CALL"
        // optie neerschrijven in het CREATE FUNCTION statement.

        // Hier cleanup doen van dure resources. Nu is dat niet nodig.
    }
}
