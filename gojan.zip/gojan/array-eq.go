package main

func main() {
	a := [3]int{6, 7, 5}
	b := [3]int{6, 7, 5}
	c := [3]int{5, 6, 7}
	print(a == b)
	print(a == c)
}
