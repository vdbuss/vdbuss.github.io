package main

func curry(f func(x, y int) int) func(int) func(int) int {
	return func(x int) func(int) int { return func(y int) int
{ return f(x, y) } }
}
func kokko(a, b int) int { return a + b }
func main() {
	var g = curry(kokko)
	var h = g(5)
	print(h(7))
}

